/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Parcial1;

/**
 *
 * @author bauti
 */
public class recursividad 
{
//sumar n elementos de un array

    public static int sumatoria(int[]a,int length,int sum)
    {
        
        if(length==0)
            return sum;
        else
        {
            sum+=a[length-1];
            return sumatoria(a,length-1,sum);
        }
    }
    
    public static void impares(int n)
{
    if(n==1)
        System.out.println(""+1);
    else
    {
        if(n%2==1)
        {
            System.out.println(""+n);
            impares(n-1);
        }
        else
            impares(n-1);
    }
}
    
    
    public static int vocales(char[] array,int suma,int length)
    {
        char n= array[length-1];
        if(length==1)
        {
            if(n=='a' || n=='e' || n=='i' || n=='o' || n=='u')
            {
                suma+=1;
                return suma;
            }else
                return suma;
        }
            
        else
        {
            if(n=='a' || n=='e' || n=='i' || n=='o' || n=='u')
            {
                suma+=1;
                return vocales(array,suma,length-1);
            }else
                return vocales(array,suma,length-1);
        }       
    }
    
    public static void main(String[] args) {
        //int[]a ={1,3,4};
        //System.out.println(sumatoria(a,a.length,0));
        //int n=10;
        //impares(n);
        //char g = 'd';
        char[] array={'a','c','i'};
        System.out.println(vocales(array,0,array.length));
    }
   
}



