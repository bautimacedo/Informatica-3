/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repasoparciali;

/**
 *
 * @author bauti
 *//*7. Implementar una función recursiva que sea capaz de sumar los n elementos
de un arreglo v de enteros solo si el valor es mayor a p*/
public class Ej4 {
    
   public static void buscarValor(int[] array, int p, int length) {
    int suma = 0;
    if (length == 1 && array[0] > p)
        suma += array[0];
    else {
        if (array[length] > p)
            suma += array[length-1];
        buscarValor(array, p, length - 1);
    }
}

    
    public static void main(String[] args) {
        int[] array = {2,3,4,5,6,7,8};
        buscarValor(array,5,array.length);
    }
}
