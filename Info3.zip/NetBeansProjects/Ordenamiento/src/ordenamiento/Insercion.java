/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ordenamiento;

/**
 *
 * @author bauti
 */
public class Insercion 
{

    private static void insertion(int[] array) {
        int  n=array.length-1,pivote;
        for(int i= 1 ; i<array.length ; i++)
        {
            int key = array[i]; //Pivote
            int j = i-1; //array[j] seria el de la izq
            while(j>= 0 && array[j]>key)
            {
                array[j+1]=array[j]; //Metemos el de la izq a la derecha
                j--;
            } 
            array[j+1]=key; //Metemos el de la derecha a la izq
            
        }
    }
    
    //public void static insertion(int[] array)
    {
        
    }
    public static void main(String[] args) {
        int[] array={3,6,1,4,9,10};
        insertion(array);
        System.out.println(array);
    }
    
}
