/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ordenamiento;

/**
 *
 * @author bauti
 */
public class Ordenamiento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        int pivote, j;
        int []array = {3,10,7,2,6};
        for(int i = 1 ; i < array.length ; i++)
        {
             pivote = array[i]; //Elemento pivote
             j = i-1; //Elemento de la izquierda del pivote
             
             while(j>=0 && pivote< array[j]) //Mientras q el pivote sea menor que el elemento de la izquierda
             {
                 array[j+1] = array[j]; //Muevo el de la izquierda a la derecha
                 j--;
             }
             array[j+1]= pivote; //Muevo el de la derecha a la izquierda
        }
        
        System.out.println("Ordenamiento Finalizado");
        for(int k = 0 ; k<array.length ; k++)
        {
            System.out.println(array[k]);
        }
        
    }
    
}
