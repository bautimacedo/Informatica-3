/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurasdd;

import java.util.Scanner;

/**
 *
 * @author bauti
 */
public class Ej1
{
    public static void main(String[] args) throws Exception 
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingresar cadena para verificar si es palindromo: ");
        String cadena = scanner.nextLine();
        cadena = cadena.trim().toLowerCase();
        StackString palindromo = new StackString(cadena.length());
        for(int ii = 0 ; ii<cadena.length() ; ii++) //mete caracteres a la pila
        {
            palindromo.push(String.valueOf(cadena.charAt(ii)));
        }
        int counter=0;
        for(int jj = 0 ; jj<cadena.length() ; jj++) //compara caracteres
        {
            if(!(String.valueOf(cadena.charAt(jj)).equals(palindromo.pop())))
                counter++;
        }
        if(cadena.length()%2==0) //Si el numero de caracteres es par
        {
        if(counter!=0)
            System.out.println("La cadena no es palindroma");
        else
            System.out.println("La cadena es palindroma");
        }else //Si el numero de caracteres es impar
        {
            if(counter==1)
            System.out.println("La cadena no es palindroma");
        else
            System.out.println("La cadena es palindroma");
        }
    }
    
}
