/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurasdd;

/**
 *
 * @author bauti
 */
public class StackString 
{
    private Integer index;

    /**
     * Tamaño del arreglo.
     */
    private Integer size;

    private String array[];

    public StackString(Integer size) {
      this.size = size;
      this.index = 0;
      this.array = new String[size];
    }

    /**
     * Agrega un valor a pila.
     */
    public void push(String item) throws Exception {
      if (isFull())
        throw new Exception("La pila está completa");

      this.array[this.index] = item;
      this.index++;
    }

    /**
     * Retorna el último valor ingresado en la pila y lo sacamos de la pila.
     * 
     * @return
     */
    public String pop() throws Exception {
      if (isEmpty()) {
        throw new Exception("La pila está vacia");
      }
      String value = this.array[this.index - 1]; // Asignamos a value el último valor de la pila.
      this.index--; // Decrementamos el índice de la pila.
      return value; // Retornamos el value.
    }

    /**
     * Retornamos el último valor.
     * 
     * @return
     */
    public String top() {
      return this.array[this.index - 1];
    }

    /**
     * Retornamo un bool para saber si la pila está vacia o no.
     * 
     * @return
     */
    public Boolean isEmpty() {
      return this.index == 0;
    }

    /**
     * Limpiamos la pila.
     */
    public void makeEmpty() {
      this.index = 0;
    }

    /**
     * @return Retornamos booleano para saber si la pila está llena.
     */
    public Boolean isFull() {
      return this.index == this.size;
    }

}    

