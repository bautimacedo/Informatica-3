package estructurasdd;

public class Main {

    public static void main(String[] args) throws Exception{
       
            // Crear una cola de tamaño 5
            Cola cola = new Cola(5);

            // Agregar elementos a la cola (encolar)
            cola.push(1);
            cola.push(2);
            cola.push(3);
            cola.push(4);
            cola.push(5);
            // Obtener y mostrar el elemento en la parte frontal de la cola
            int elementoFrontal = cola.top();
            System.out.println("Elemento en la parte frontal de la cola: " + elementoFrontal);

            // Sacar elementos de la cola (desencolar) y mostrarlos
            System.out.println("Elementos desencolados:");
            while (!cola.isEmpty()) {
                int elemento = cola.pop();
                System.out.println(elemento);
            }

            // Verificar si la cola está vacía
            if (cola.isEmpty()) {
                System.out.println("La cola está vacía.");
            } else {
                System.out.println("La cola no está vacía.");
            }
       
        }
    }
