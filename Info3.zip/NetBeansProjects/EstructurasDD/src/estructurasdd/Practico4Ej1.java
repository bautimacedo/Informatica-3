/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurasdd;

import java.util.Scanner;

/**
 *
 * @author bauti
 */
public class Practico4Ej1 
{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StackList<String> pila = new StackList<>();
        System.out.println("Cuantas palabras desea ingresar en la pila: ");
        int size = scanner.nextInt();
        for(int i = 0 ; i<size+1 ; i++)
        {
            System.out.println("Palabra N "+i);
            pila.push(scanner.nextLine());
        }
        
        for(int j = 0 ; j<size ; j++)
        {
            System.out.println("Elementos \n");
            System.out.println(pila.pop());
            System.out.println();
        }
        
    }
}
