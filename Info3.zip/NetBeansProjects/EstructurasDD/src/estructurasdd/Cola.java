
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurasdd;

/**
 *
 * @author bauti
 */
public class Cola 
{
    private Integer index;
    private Integer indexpop;
    private Integer size;
    private Integer array[];
    
    public Cola(Integer size){
        this.size=size;
        this.index = 0;
        this.indexpop=-1;
        this.array = new Integer[size];
    } 
    public void push(Integer element) throws Exception{
        if(isFull())
            throw new Exception("La pila esta llena");
        this.array[this.index]= element;
        this.index++;
    }
    
    //Retorna el  ultimo valor y lo saca
    public Integer pop() throws Exception{
        if(isEmpty())
            throw new Exception("La pila esta vacia");
        //Unicamente saca un index asi se deja listo para
        //sobreescribir en el proximo push
        int elemento = this.array[this.indexpop+1];
        this.indexpop++;
        return elemento;
    }
    
    //Retorna el ultimo valor 
    public Integer top(){
        if(this.indexpop==-1)
            return this.array[this.indexpop+1];
        else
            return this.array[this.indexpop];
    }
    
    public Boolean isEmpty(){
        return this.index == 0;
    }
    
    public void makeEmpty(){
        this.index=0;
    }
    
    public boolean isFull(){
        return this.index == this.size;
    }
    
    public void main(String[] args) throws Exception {
        Cola colita = new Cola(5);
        push(2);
    }
}

