
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurasdd;

/**
 *
 * @author bauti
 */
public class Stack 
{
    private Integer index;
    private Integer size;
    private Integer array[];
    
    public Stack(Integer size){
        this.size=size;
        this.index = 0;
        this.array = new Integer[size];
    }
    public void push(Integer element) throws Exception{
        if(isFull())
            throw new Exception("La pila esta llena");
        this.array[this.index]= element;
        this.index++;
    }
    
    //Retorna el  ultimo valor y lo saca
    public Integer pop() throws Exception{
        if(isEmpty())
            throw new Exception("La pila esta vacia");
        //Unicamente saca un index asi se deja listo para
        //sobreescribir en el proximo push
        this.index--;
        return this.array[this.index];
    }
    
    //Retorna el ultimo valor 
    public Integer top(){
        return this.array[this.index-1];
    }
    
    public Boolean isEmpty(){
        return this.index == 0;
    }
    
    public void makeEmpty(){
        this.index=0;
    }
    
    public boolean isFull(){
        return this.index == this.size;
    }
}
