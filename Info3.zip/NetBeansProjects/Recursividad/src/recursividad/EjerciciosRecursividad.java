/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package recursividad;

public class EjerciciosRecursividad {

    /*2. Escribe una función recursiva que calcule la suma de los primeros n enteros
    positivos. Por ejemplo, n=4 es 1+2+3+4=10.*/
    public static int sumatoria(int k)
    {
        if(k==1)
            return 1;
        else
          return k+sumatoria(k-1);
    }
    /*1. Escribe una función recursiva que calcule el factorial de un número entero positivo n.
    Por ejemplo, 4! es 1x2x3x4=24.*/
    public static int factorial(int x)
    {
        if(x==0)
            return 1;
        else
            return x*factorial(x-1);
    }
    /*3. Escribe una función recursiva que calcule la potencia de un número base elevado a
    un exponente. Por ejemplo, 2^3=2*2*2=8*/
    public static int potencial(int base, int p)
    {
        if(p==0)
            return 1;
        else
            return base*potencial(base,p-1);
    }    
    /*4. Escribe una función recursiva que imprima un conteo regresivo desde un número n
    hasta 1. Por ejemplo, n=4 es 4,3,2,1.*/
    public static void conteo(int n)
    {
        if(n==0)
            System.out.println(""+0);
        else
        {
            System.out.println(""+n);
            conteo(n-1);
        }
    }
    
    /*5. Escriba un método recursivo que calcule el producto de dos números enteros
        usando sumas sucesivas. Por ejemplo, 2x4=2+2+2+2=8*/
    public static int multi(int num1, int num2)
    {
        if(num2==1)
            return num1;
        else
            return num1+multi(num1,num2-1);
    }
    /*6. Escriba un método recursivo que imprima los elementos de un arreglo en orden
    inverso.*/
    public static void printArray(int[] array,int length)
    {
        if(length==1)
            System.out.println(""+array[0]);
        else
        {
            System.out.println(""+array[length-1]);
            printArray(array,length-1);
        }    
    }
    
    public static void main(String[] args) {
        //System.out.println(factorial(3)); //ejercicio 1
        //System.out.println(sumatoria(5)); //ejercicio 2
        //System.out.println(potencial(2,5)); //ejercicio 3
        //conteo(3); //ejercicio 4
        //System.out.println(multi(2,7)); //ejercicio 5
        //int[] a = {1,2,3,4,5}; // ejercicio 6
        //printArray(a,a.length); // ejercicio 6
        
    }
    
}
