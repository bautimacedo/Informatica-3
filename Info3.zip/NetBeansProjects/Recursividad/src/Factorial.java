/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author bauti
 */
public class Factorial {
    
    
    public static int factorial (int x)
    {
        if(x==1)
            return 1;
        else
            return (x*factorial(x-1));
    }
    
    public static int sumatoria (int x)
    {
        if(x==1)
            return 1;
        else
            return (x+factorial(x+1));
    }
    
    public static void main(String[] args) {
        int a=3;
        System.out.println(factorial(a));
        System.out.println(sumatoria(3));
    }
}
