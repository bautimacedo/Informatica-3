/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurasenlazadas;

/**
 *
 * @author bauti
 */
public class StackListMio<AnyType>
{
    private Nodo<AnyType> root = null;    
    
    public void push (AnyType element)
    {
        Nodo<AnyType> nodo = new Nodo<AnyType>(element);
        nodo.next=root;
        root=nodo;
    }
    
    
     public AnyType pop()
    {
        AnyType valor = root.data;
        root=root.next;
        return valor;
    }
     
    public AnyType top(){
            return root.data;}
    
    public boolean isEmpty()
    {
        return this.root==null;
    }
    
    public void makeEmpty()
    {
        this.root=null;
    }
    
    public int size()
    {
        int count=0;
        Nodo<AnyType> recorrer = this.root;
        while(this.root!=null)
        {
            count++;
            recorrer=recorrer.next;
        }
        return count;
    }
    
}
