/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurasenlazadas;

/**
 *
 * @author bauti
 */
public class ColaListMia<AnyType> 
{
    private Nodo <AnyType> front;
    private Nodo <AnyType>  back;
    
    public ColaListMia()
    {
        this.front=null;
        this.back=null;
    }       
      
    public void push(AnyType data)
    {
        Nodo<AnyType> nodo = new Nodo<AnyType>(data);
        if(this.front==null)
        {
            front=nodo;
            back=nodo;
        }else
        {
            back.next=nodo;
            back=nodo;
        }
    }
   
    public AnyType pop()
    {
        if(isEmpty())
            throw new Exception();
        AnyType value = front.data;
        front=front.next;
        if(front==null)
            back=null;
        return value;
    }
    
    public boolean isEmpty(){
        return front==null ;
    }
    
    
    public AnyType top(){
        return front.data;
    }
    
    
    
}
