package pkg17del8;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
   int a=0;
   int b=0;
   HashMap<Integer, Integer> memory = new HashMap<>(); 
   int ctr=0;
    Scanner scanner = new Scanner(System.in);
    
    try{
        System.out.println("Ingrese a: ");
        a= scanner.nextInt();

        System.out.println("Ingrese b: ");
        b= scanner.nextInt();    
    }catch(Exception e)
    {
        System.out.println("Se ingreso un valor distinto a un entero");
    }   
    
    
    System.out.println("1:Sumar\n2:Restar\n3:Multiplicar\n4:Dividir\n5:Historial");
    int opcion= scanner.nextInt();
    int x=0;
                 
                switch (opcion) {
                  case 1:
                      x=Calculadora.sumar(a,b);
                      System.out.println(x);
                      ctr++;
                      memory.put(x,ctr);
                    break;

                 case 2:
                      x=Calculadora.restar(a,b);
                      System.out.println(x);
                      ctr++;
                      memory.put(x,ctr);
                    break;

                    case 3:
                      x= Calculadora.multiplicar(a,b);
                      System.out.println(x);
                      ctr++;
                      memory.put(x,ctr);
                    break;

                    case 4:
                      x= Calculadora.dividir(a,b);
                      System.out.println(x);
                      ctr++;
                      memory.put(x,ctr);
                    break;

                    case 5:
                        for(Entry<Integer,Integer> map : memory.entrySet())
                        {
                            System.out.println("Numero de Operacion: " + map.getKey());
                            System.out.println("Resultado de Operacion: " + map.getValue());
                            System.out.println();
                        }
                        break;
                }
           
  }
}
