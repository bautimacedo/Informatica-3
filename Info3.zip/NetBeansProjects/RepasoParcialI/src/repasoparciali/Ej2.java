/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repasoparciali;

/**
 *
 * @author bauti
 */
/*2. Escriba una función void recursiva que reciba como parámetro solo un
entero positivo n y que despliegue todos los enteros impares menores a n.*/
public class Ej2 {
    
    public static void imparesMenores (int n)
    {
        if(n==1)
            System.out.println(""+1);
        else
        {
            if(n%2==0)
            {
                imparesMenores(n-1);
            }
            else
            {
                System.out.println(""+n);
                imparesMenores(n-1);
            }
        }
    }
    
    public static void main(String[] args) {
        int n=15;
        imparesMenores(n);
    }
}
