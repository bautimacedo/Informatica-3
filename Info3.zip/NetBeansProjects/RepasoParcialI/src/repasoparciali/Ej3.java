/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repasoparciali;

/**
 *
 * @author bauti
 */
/*3. Escribir una función recursiva que tenga un parámetro que sea entero
positivo y despliegue en la pantalla ese número de asteriscos: “*”, todos en
una línea.*/
public class Ej3 {
    
    public static void asteriscos(int n)
    {
        if(n==1)
            System.out.print("*");
        else
        {
            System.out.print("*");
            asteriscos(n-1);
        }    
    }
    
    public static void main(String[] args) {
        asteriscos(8);
    }
}
