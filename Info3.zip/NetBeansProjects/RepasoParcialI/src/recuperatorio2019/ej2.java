/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recuperatorio2019;

/**
 *
 * @author bauti
 */
public class ej2 
{
    public int sumatoria(Nodo nodo, int n,int suma)
    {
        if(nodo==null)
            return suma;
        if((int)nodo.data>n)
            suma+=(int)nodo.data;
            return sumatoria(nodo.next,n,suma);   
    }
    
    public void mover(Nodo nodo,int posicion,Nodo root) throws Exception
    {
        Nodo temp=nodo;
        for(int i=0 ; i<posicion ; i++)
        {
            if(temp.next!=null)
                temp=temp.next;
            else
                throw new Exception("");
        }
        temp=nodo;
        root=root.next;
        
    }
}
