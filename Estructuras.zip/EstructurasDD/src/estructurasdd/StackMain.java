
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurasdd;
/**
 *
 * @author bauti
 */
public class StackMain
{
 
    public static void main(String[] args) throws Exception{
        System.out.println("Main");
        
        Stack stack = new Stack(4);
        for(int ii = 0 ; ii< 4 ; ii++)
        {
            stack.push(ii);
        }
        
        stack.pop();
        
    }
    
}
