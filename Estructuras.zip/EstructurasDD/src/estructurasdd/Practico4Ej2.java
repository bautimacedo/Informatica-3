/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurasdd;

import java.util.Scanner;

/**
a. Escribe un programa que verifique si una expresión matemática tiene
paréntesis balanceados. Por ejemplo, para la expresión ((3+2)*5) la
salida debería ser "Paréntesis balanceados", mientras que para
((3+2)*5)) la salida debería ser "Paréntesis desbalanceados".
 */
public class Practico4Ej2 {
   
    public static void main(String[] args) 
    {
     
        StackList<String> pila = new StackList<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingresar expresion matematica: ");
        String cadena = scanner.nextLine();
        String verif = "";
        int counter1=0,counter2=0;
        for(int i = 0 ; i < cadena.length() ; i++)
        {
            verif += cadena.charAt(i);
            if(verif.contains("("))
                pila.push(verif);
            try{
            if(verif.contains(")"))
                pila.pop();    
            }catch(NullPointerException npe){
                System.out.println("La expresion esta incorrecta");
                //Linea que sale del codigo
            }
            
            verif= "";
        }
        
        if(pila.isEmpty())
            System.out.println("La expresion es correcta");
        else
        {
            pila.makeEmpty();
            System.out.println("La expresion esta mal");
        }
            
    }
}
